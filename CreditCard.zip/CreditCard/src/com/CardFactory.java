package com;

public interface CardFactory {
    Card createCard (String card_number);
}
